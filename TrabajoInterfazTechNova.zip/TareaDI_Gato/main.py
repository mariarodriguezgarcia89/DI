import sys
import os
from PySide6.QtWidgets import QApplication, QMainWindow, QLabel, QMessageBox
from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QPoint, QEasingCurve, QTimer
from PySide6.QtGui import QMovie, QTransform, QPalette, QBrush, QIcon, QPixmap

from archivo import Ui_MainWindow  # Tu archivo .py generado por Qt Designer

class GatuxoApp(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.explotado = False
        self.timer_accion = None

        self.ruta_imagenes = os.path.join(os.path.dirname(__file__), "imagenes")

        # Fuente e iconos toolbar
        fuente = self.font()
        fuente.setPointSize(14)
        self.setFont(fuente)
        self.toolBar.setIconSize(QSize(64, 64))

        self.actionDar_de_comer.setIcon(QIcon(os.path.join(self.ruta_imagenes, "comida-enlatada.png")))
        self.actionAcariciar.setIcon(QIcon(os.path.join(self.ruta_imagenes, "amante-de-los-gatos.png")))
        self.actionDormir.setIcon(QIcon(os.path.join(self.ruta_imagenes, "siesta.png")))

        self.actionDar_de_comer.triggered.connect(lambda: self.realizar_accion("comiendo"))
        self.actionAcariciar.triggered.connect(lambda: self.realizar_accion("acariciado"))
        self.actionDormir.triggered.connect(lambda: self.realizar_accion("durmiendo"))
        self.actionSalir.triggered.connect(self.close)
        self.actionAcerca_de.triggered.connect(self.mostrar_acerca_de)

        # QLabel del GIF
        self.etiqueta_gato = QLabel(self.centralwidget)
        self.etiqueta_gato.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.etiqueta_gato.resize(200, 200)

        # GIF inicial
        self.moviendo_derecha = True
        self.gif_inicial = QMovie(os.path.join(self.ruta_imagenes, "GatoWalk.gif"))
        self.gif_inicial.setScaledSize(QSize(200, 200))
        self.etiqueta_gato.setMovie(self.gif_inicial)
        self.gif_inicial.frameChanged.connect(self.actualizar_frame)
        self.gif_inicial.start()

        # Animación caminar
        self.animacion = QPropertyAnimation(self.etiqueta_gato, b"pos")
        self.animacion.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self.animacion.finished.connect(self.invertir_animacion)

        # GIFs acciones
        self.gifs_accion = {
            "comiendo": QMovie(os.path.join(self.ruta_imagenes, "gato_comiendo.gif")),
            "durmiendo": QMovie(os.path.join(self.ruta_imagenes, "gato_durmiendo.gif")),
            "acariciado": QMovie(os.path.join(self.ruta_imagenes, "gato_acariciando.gif"))
        }
        for gif in self.gifs_accion.values():
            gif.setScaledSize(QSize(250, 250))

        # Fondo y barras
        self.actualizar_fondo()
        self.progressFelicidad.setValue(0)
        self.progressHambre.setValue(0)
        self.progressCansancio.setValue(0)

        self.gif_explosion = None
        self.y_gato = None

    # -------------------
    # Eventos de ventana
    # -------------------
    def resizeEvent(self, evento):
        self.actualizar_fondo()
        super().resizeEvent(evento)

    def showEvent(self, evento):
        super().showEvent(evento)
        tam_central = self.centralwidget.size()
        ancho_gif, alto_gif = 200, 200
        x_inicio = 50
        x_fin = tam_central.width() - ancho_gif - 50
        self.y_gato = tam_central.height() - alto_gif - -160
        self.etiqueta_gato.setGeometry(x_inicio, self.y_gato, ancho_gif, alto_gif)
        self.animacion.setDuration(4000)
        self.animacion.setStartValue(QPoint(x_inicio, self.y_gato))
        self.animacion.setEndValue(QPoint(x_fin, self.y_gato))
        self.animacion.start()

    # -------------------
    # Fondo
    # -------------------
    def actualizar_fondo(self):
        palette = QPalette()
        pixmap = QPixmap(os.path.join(self.ruta_imagenes, "fondo.jpg")).scaled(
            self.centralwidget.size(),
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        palette.setBrush(QPalette.ColorRole.Window, QBrush(pixmap))
        self.centralwidget.setAutoFillBackground(True)
        self.centralwidget.setPalette(palette)

    # -------------------
    # Animación caminar
    # -------------------
    def invertir_animacion(self):
        inicio = self.animacion.startValue()
        fin = self.animacion.endValue()
        self.animacion.setStartValue(fin)
        self.animacion.setEndValue(inicio)
        self.moviendo_derecha = not self.moviendo_derecha
        self.animacion.start()

    def actualizar_frame(self):
        frame = self.gif_inicial.currentPixmap()
        if self.moviendo_derecha:
            frame = frame.transformed(QTransform().scale(-1, 1))
        self.etiqueta_gato.setPixmap(frame)

    def detener_animacion(self):
        self.animacion.pause()
        self.gif_inicial.setPaused(True)
        if self.timer_accion:
            self.timer_accion.stop()

    def reanudar_animacion(self):
        self.animacion.resume()
        self.gif_inicial.setPaused(False)

    # -------------------
    # Acciones - CORREGIDO posicionamiento de QMessageBox
    # -------------------
    def realizar_accion(self, accion):
        if self.explotado:
            return

        # Verificar si la barra correspondiente ya está al máximo
        if accion == "comiendo" and self.progressHambre.value() == 100:
            self._mostrar_mensaje_limite("No se puede alimentar más", "¡El gato tiene la panza llena! 🐱💕")
            return
        elif accion == "durmiendo" and self.progressCansancio.value() == 100:
            self._mostrar_mensaje_limite("No se puede dormir más", "¡El gato está completamente descansado! 🐱😴")
            return
        elif accion == "acariciado" and self.progressFelicidad.value() == 100:
            self._mostrar_mensaje_limite("No se puede acariciar más", "¡El gato está super feliz! 🐱💖")
            return

        # Actualizar barra correspondiente
        if accion == "comiendo":
            self.progressHambre.setValue(min(100, self.progressHambre.value() + 10))
            mensaje = ("ÑAM ÑAM", "¡Alimentando al gato!")
        elif accion == "durmiendo":
            self.progressCansancio.setValue(min(100, self.progressCansancio.value() + 10))
            mensaje = ("ZZZZ", "¡Durmiendo al gato!")
        elif accion == "acariciado":
            self.progressFelicidad.setValue(min(100, self.progressFelicidad.value() + 10))
            mensaje = ("PURR", "¡Acariciando al gato!")
        else:
            return

        # Comprobar explosión primero
        if self.comprobar_explosion():
            return

        # Usar un timer para mostrar el mensaje después de que la UI se actualice
        QTimer.singleShot(100, lambda: self._mostrar_mensaje_accion(mensaje, accion))

    def _mostrar_mensaje_limite(self, titulo, mensaje):
        """Muestra un mensaje cuando una acción ha llegado al límite"""
        msg = QMessageBox(self)
        msg.setWindowTitle(titulo)
        msg.setText(mensaje)
        msg.setIcon(QMessageBox.Icon.Warning)
        
        # Usar el mismo método de posicionamiento para consistencia
        self._mostrar_y_posicionar_mensaje(msg, "centro")

    def _mostrar_mensaje_accion(self, mensaje, accion):
        """Muestra el mensaje de acción centrado sobre el gato"""
        titulo, texto = mensaje
        
        # Crear y configurar el messagebox
        msg = QMessageBox(self)
        msg.setWindowTitle(titulo)
        msg.setText(texto)
        msg.setIcon(QMessageBox.Icon.Information)

        # Configurar icono según la acción
        if accion == "comiendo":
            msg.setWindowIcon(QIcon(os.path.join(self.ruta_imagenes, "comida-enlatada.png")))
            msg.setIconPixmap(QPixmap(os.path.join(self.ruta_imagenes, "comida-enlatada.png")).scaled(64, 64))
        elif accion == "acariciado":
            msg.setWindowIcon(QIcon(os.path.join(self.ruta_imagenes, "amante-de-los-gatos.png")))
            msg.setIconPixmap(QPixmap(os.path.join(self.ruta_imagenes, "amante-de-los-gatos.png")).scaled(64, 64))
        elif accion == "durmiendo":
            msg.setWindowIcon(QIcon(os.path.join(self.ruta_imagenes, "siesta.png")))
            msg.setIconPixmap(QPixmap(os.path.join(self.ruta_imagenes, "siesta.png")).scaled(64, 64))

        # Mostrar y posicionar el mensaje
        self._mostrar_y_posicionar_mensaje(msg, "sobre_gato", accion)

    def _mostrar_y_posicionar_mensaje(self, msg, posicion, accion=None):
        """Método unificado para mostrar y posicionar QMessageBox"""
        
        # Función para posicionar después de que se muestre
        def posicionar_mensaje():
            if posicion == "sobre_gato":
                # Posicionar centrado sobre el gato
                x_gato = self.etiqueta_gato.x()
                y_gato = self.etiqueta_gato.y()
                ancho_gato = self.etiqueta_gato.width()
                
                x_msg = x_gato + (ancho_gato - msg.width()) // 2
                y_msg = y_gato - msg.height() - 20
                
                # Asegurarse de que no se salga de la pantalla
                x_msg = max(0, min(x_msg, self.width() - msg.width()))
                y_msg = max(0, y_msg)
                
                msg.move(x_msg, y_msg)
            else:  # "centro"
                # Posicionar en el centro de la ventana
                x_ventana = self.x()
                y_ventana = self.y()
                ancho_ventana = self.width()
                alto_ventana = self.height()
                
                x_msg = x_ventana + (ancho_ventana - msg.width()) // 2
                y_msg = y_ventana + (alto_ventana - msg.height()) // 2
                
                msg.move(x_msg, y_msg)
            
            # Conectar el cierre si es una acción normal
            if accion is not None:
                msg.finished.connect(lambda: self.mostrar_gif_accion_final(accion))

        # Conectar el evento de mostrar para posicionar después del render
        msg.showEvent = lambda event: QTimer.singleShot(10, posicionar_mensaje)
        
        # Mostrar el mensaje
        msg.show()
        msg.activateWindow()
        msg.raise_()

    def mostrar_gif_accion_final(self, nombre_accion):
        if self.explotado:
            return
        self.detener_animacion()
        gif = self.gifs_accion[nombre_accion]
        gif.stop()
        gif.jumpToFrame(0)
        self.etiqueta_gato.setMovie(gif)
        gif.start()
        ancho = gif.scaledSize().width()
        alto = gif.scaledSize().height()
        ancho_ventana = self.centralwidget.width()
        alto_ventana = self.centralwidget.height()
        self.etiqueta_gato.setGeometry(
            (ancho_ventana - ancho) // 2,
            (alto_ventana - alto) // 2,
            ancho,
            alto
        )
        QTimer.singleShot(5000, self.mostrar_gif_inicial)

    def mostrar_gif_inicial(self):
        if self.explotado:
            return
        self.etiqueta_gato.setMovie(self.gif_inicial)
        self.gif_inicial.start()
        self.reanudar_animacion()
        tam_gif = QSize(200, 200)
        x_actual = self.etiqueta_gato.x()
        self.etiqueta_gato.setGeometry(x_actual, self.y_gato, tam_gif.width(), tam_gif.height())

    # -------------------
    # Explosión
    # -------------------
    def comprobar_explosion(self):
        if (self.progressHambre.value() == 100 and
            self.progressCansancio.value() == 100 and
            self.progressFelicidad.value() == 100 and
            not self.explotado):
            self.explotado = True
            # Primero mostrar el mensaje, luego la explosión
            self.mostrar_explosion_mensaje()
            return True
        return False

    def mostrar_explosion_mensaje(self):
        """Muestra el mensaje de explosión y luego inicia la animación"""
        msg = QMessageBox(self)
        msg.setWindowTitle("¡BOOM!")
        msg.setText("El gatito ha explotado de felicidad 💥🐱")
        msg.setIcon(QMessageBox.Icon.Warning)
        
        # Conectar el cierre del mensaje para mostrar la explosión
        msg.finished.connect(self.gato_explosion)
        
        # Usar el mismo método de posicionamiento
        self._mostrar_y_posicionar_mensaje(msg, "centro")
        msg.exec()

    def gato_explosion(self):
        """Muestra la animación de explosión completa"""
        self.detener_animacion()
        
        # Cargar el GIF de explosión
        self.gif_explosion = QMovie(os.path.join(self.ruta_imagenes, "gato_explotando.gif"))
        self.gif_explosion.setScaledSize(QSize(400, 400))
        self.etiqueta_gato.setMovie(self.gif_explosion)
        
        # Centrar el GIF
        ancho = self.gif_explosion.scaledSize().width()
        alto = self.gif_explosion.scaledSize().height()
        ancho_ventana = self.centralwidget.width()
        alto_ventana = self.centralwidget.height()
        self.etiqueta_gato.setGeometry(
            (ancho_ventana - ancho) // 2,
            (alto_ventana - alto) // 2,
            ancho,
            alto
        )
        
        # Conectar la señal de frameChanged para saber cuándo termina
        self.gif_explosion.frameChanged.connect(self._verificar_fin_explosion)
        self.gif_explosion.start()

    def _verificar_fin_explosion(self, frame_number):
        """Verifica si la explosión ha terminado"""
        if frame_number == self.gif_explosion.frameCount() - 1:
            # El GIF llegó al último frame, desconectar la señal
            self.gif_explosion.frameChanged.disconnect(self._verificar_fin_explosion)
            # Opcional: mantener el último frame visible
            self.gif_explosion.jumpToFrame(self.gif_explosion.frameCount() - 1)

    # -------------------
    # Acerca de
    # -------------------
    def mostrar_acerca_de(self):
        QMessageBox.information(
            self,
            "Acerca de",
            "Esta aplicación muestra un gato interactivo con animaciones y barras de estado.\nCreado con PySide6."
        )

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = GatuxoApp()
    ventana.showMaximized()
    sys.exit(app.exec())