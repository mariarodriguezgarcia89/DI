# -*- coding: utf-8 -*-

from PySide6.QtCore import (QCoreApplication, QRect, QSize, Qt, QMetaObject)
from PySide6.QtGui import QIcon, QAction
from PySide6.QtWidgets import (QApplication, QMainWindow, QMenu, QMenuBar,
                               QStatusBar, QToolBar, QVBoxLayout, QWidget,
                               QLabel, QProgressBar)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)

        # Acciones
        self.actionDar_de_comer = QAction(MainWindow)
        self.actionDar_de_comer.setObjectName(u"actionDar_de_comer")
        icon = QIcon()
        icon.addFile(u"../../../../Downloads/comida-enlatada.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionDar_de_comer.setIcon(icon)

        self.actionAcariciar = QAction(MainWindow)
        self.actionAcariciar.setObjectName(u"actionAcariciar")
        icon1 = QIcon()
        icon1.addFile(u"../../../../Downloads/amante-de-los-gatos.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionAcariciar.setIcon(icon1)

        self.actionDormir = QAction(MainWindow)
        self.actionDormir.setObjectName(u"actionDormir")
        icon2 = QIcon()
        icon2.addFile(u"../../../../Downloads/siesta.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionDormir.setIcon(icon2)

        self.actionSalir = QAction(MainWindow)
        self.actionSalir.setObjectName(u"actionSalir")

        self.actionAcerca_de = QAction(MainWindow)
        self.actionAcerca_de.setObjectName(u"actionAcerca_de")

        # Central widget
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")

        # Layout vertical con labels y progress bars
        self.verticalLayoutWidget = QWidget(self.centralwidget)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(20, 20, 250, 300))
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)

        # Labels y ProgressBars
        self.labelFelicidad = QLabel(self.verticalLayoutWidget)
        self.labelFelicidad.setText("Felicidad")
        self.verticalLayout.addWidget(self.labelFelicidad)

        self.progressFelicidad = QProgressBar(self.verticalLayoutWidget)
        self.progressFelicidad.setValue(50)
        self.verticalLayout.addWidget(self.progressFelicidad)

        self.labelHambre = QLabel(self.verticalLayoutWidget)
        self.labelHambre.setText("Hambre")
        self.verticalLayout.addWidget(self.labelHambre)

        self.progressHambre = QProgressBar(self.verticalLayoutWidget)
        self.progressHambre.setValue(50)
        self.verticalLayout.addWidget(self.progressHambre)

        self.labelCansancio = QLabel(self.verticalLayoutWidget)
        self.labelCansancio.setText("Cansancio")
        self.verticalLayout.addWidget(self.labelCansancio)

        self.progressCansancio = QProgressBar(self.verticalLayoutWidget)
        self.progressCansancio.setValue(50)
        self.verticalLayout.addWidget(self.progressCansancio)

        MainWindow.setCentralWidget(self.centralwidget)

        # Menubar
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 33))

        self.menuMen = QMenu(self.menubar)
        self.menuMen.setObjectName(u"menuMen")
        self.menuMen.setTitle("Menú")
        self.menuMen.addAction(self.actionDar_de_comer)
        self.menuMen.addAction(self.actionAcariciar)
        self.menuMen.addAction(self.actionDormir)
        self.menuMen.addAction(self.actionSalir)

        self.menuAyuda = QMenu(self.menubar)
        self.menuAyuda.setObjectName(u"menuAyuda")
        self.menuAyuda.setTitle("Ayuda")
        self.menuAyuda.addAction(self.actionAcerca_de)

        self.menubar.addAction(self.menuMen.menuAction())
        self.menubar.addAction(self.menuAyuda.menuAction())
        MainWindow.setMenuBar(self.menubar)

        # StatusBar
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        # Toolbar
        self.toolBar = QToolBar(MainWindow)
        self.toolBar.setObjectName(u"toolBar")
        MainWindow.addToolBar(Qt.ToolBarArea.TopToolBarArea, self.toolBar)
        self.toolBar.addAction(self.actionDar_de_comer)
        self.toolBar.addAction(self.actionAcariciar)
        self.toolBar.addAction(self.actionDormir)

        self.retranslateUi(MainWindow)
        QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle("MainWindow")
        self.actionDar_de_comer.setText("Dar de comer")
        self.actionAcariciar.setText("Acariciar")
        self.actionDormir.setText("Dormir")
        self.actionSalir.setText("Salir")
        self.actionAcerca_de.setText("Acerca de")
